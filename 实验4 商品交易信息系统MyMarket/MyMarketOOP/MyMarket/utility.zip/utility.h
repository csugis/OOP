#ifndef _UTILITY_H
#define _UTILITY_H

#include "MyMarket.h"

extern int ParseString(const char *str, char *word[], const char delim = ',');

extern void StringToDate(const char *str, Date &date);

extern void StringToTime(const char *str, Time &time);

extern UINT64 StringToPhone(const char *str);

extern void ReverseOrders(Order orders[], int nOrders);

extern void GetCurrentTime(Time &time);

extern bool CheckDate(const Date &date);

extern char* TimeToString(const Time &time, char *buffer, int BufferSize = 20);

extern char* DateToString(const Date &date, char *buffer, int BufferSize = 11);

extern void GeneratePassword(char *pwd, int len);

#endif // _UTILITY_H

